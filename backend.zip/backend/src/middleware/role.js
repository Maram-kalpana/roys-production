const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ success: false, message: 'Authentication required' })
  }
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ success: false, message: 'Access denied' })
  }
  next()
}

const superAdminOnly = requireRole('super_admin')

const anyAdmin = requireRole('super_admin', 'admin')

module.exports = {
  requireRole,
  superAdminOnly,
  anyAdmin,
}
